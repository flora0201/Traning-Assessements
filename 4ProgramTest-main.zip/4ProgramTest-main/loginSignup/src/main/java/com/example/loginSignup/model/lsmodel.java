package com.example.loginSignup.model;

import com.example.loginSignup.repository.lsrepository;
import org.springframework.beans.factory.annotation.Autowired;

public class lsmodel {
    @Autowired
    lsrepository lsrepositoryobj;
}
