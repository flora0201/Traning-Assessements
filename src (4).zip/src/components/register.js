import React,{Component} from 'react';
import axios from 'axios';
export default class Register extends Component{
    handleSubmit = e =>{
        e.preventDefault();
        const data={
            name:this.name,
            email:this.email,
            pasword:this.password,
            password_confirm:this.confirmPassword
        };
        
        axios.post('http://localhost:8080/register',data)
        .then(res => {
                console.log(res);
            })
            .catch(err => {
                console.log(err)
            })

        console.log('works!');
    };
    render(){
        return(
        <form onSubmit={this.handleSubmit}>
            <h3>Create user</h3>
            <div className="form-group">
                <label>Name</label>
                <input type="name" className="form-control" placeholder="Enter your Name"
                onChange={e => this.name=e.target.value}/>
            </div>
            <div className="form-group">
                <label>Email</label>
                <input type="email" className="form-control" placeholder="Enter your Email"
                onChange={e => this.email=e.target.value}/>
            </div>
            <div className="form-group">
                <label>Password</label>
                <input type="password" className="form-control" placeholder="Enter your Password"
                onChange={e => this.password=e.target.value}/>
            </div>
            <div className="form-group">
                <label>Confirm Password</label>
                <input type="password" className="form-control" placeholder="Enter your Confirm Password"
                onChange={e => this.confirmPassword=e.target.value}/>
            </div>
            <button className="btn btn-primary btn-block">Signup</button>
            </form>
        )
    }
}
