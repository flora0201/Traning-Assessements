import React,{Component} from 'react';
import { Link } from 'react-router-dom';
export default class Home extends Component{
    render(){
        return(
            <form>
            <p className="login text-center">
                <Link to={'/login'}>Go to LOGIN</Link>
            </p>
            <p className="signup text-center">
                <Link to={'/register'}>Go to SIGNUP</Link>
            </p>
            
            <h1>Welcome</h1>
            </form>
        )
}
}

