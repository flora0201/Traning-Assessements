package com.example.springcontact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcontactApplicationTests {

	@Test
	void contextLoads() {
	}

}
