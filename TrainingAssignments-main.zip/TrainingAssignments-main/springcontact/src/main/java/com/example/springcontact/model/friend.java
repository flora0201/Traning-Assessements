package com.example.springcontact.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class friend {
    private String name;
    private String phoneno;
    private String email;
}
