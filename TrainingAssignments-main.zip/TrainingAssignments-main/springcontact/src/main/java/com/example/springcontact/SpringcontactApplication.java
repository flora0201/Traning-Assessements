package com.example.springcontact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcontactApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcontactApplication.class, args);
	}

}
