package com.example.springContactBook.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Friend {
    private String firstname;
    private String lastname;
    private String phoneno;
    private String email;
}
