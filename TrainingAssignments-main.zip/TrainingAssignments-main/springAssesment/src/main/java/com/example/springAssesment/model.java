package com.example.springAssesment;

import org.springframework.beans.factory.annotation.Autowired;

public class model {
    @Autowired
    com.example.springAssesment.repository repository;
}
