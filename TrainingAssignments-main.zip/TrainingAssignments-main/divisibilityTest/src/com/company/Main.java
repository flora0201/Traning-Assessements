package com.company;
import java.sql.SQLOutput;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Myclass obj = new Myclass();
        obj.input();
        obj.divisors();
        obj.decision();
    }
}

