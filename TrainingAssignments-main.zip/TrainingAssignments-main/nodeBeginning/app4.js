var persons=[];
var a={
    "name":"Aayush",
    "age":"24",
    "occupation":"ModernDaySlave"
}

persons.push(a);

let myPerson = (persons) =>{}